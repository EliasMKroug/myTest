import React from 'react';
import { descriptions,descriptions2 } from '../descriptions';

interface JobData {
  Estado: string;
  Host: string;
  Nombre: string;
  Project: string;
}

interface DataTableProps {
  filteredData: JobData[];
  handleSort: (key: string) => void;
}

const getDescription = (nombre: string) => {
  for (const key in descriptions) {
    if (nombre.includes(key)) {
      return descriptions[key];
    }
  }
  return '';
};

const getDescription2 = (project: string) => {
  for (const key in descriptions) {
    if (project == key) {
      return descriptions[key];
    }
  }
  return '';
};

const getDescription3 = (nombre: string) => {
  for (const key in descriptions2) {
    if (nombre == key) {
      return descriptions2[key];
    }
  }
  return '';
};

const exportToCSV = (filteredData: JobData[]) => {
  
  const headers = ['Project', 'Hypervisor', 'Instancia', 'Estado', 'Descripcion'];

  
  const rows = filteredData.map((data) => [
    data.Project,
    data.Host,
    data.Nombre,
    data.Estado,
    getDescription(data.Project)
  ]);

  
  const csvContent = [headers, ...rows]
    .map(row => row.join(','))
    .join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', 'output.csv');
  link.style.visibility = 'hidden'; 
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

const DataTable: React.FC<DataTableProps> = ({ filteredData, handleSort }) => {
  return (
    <div style={{ backgroundColor: '#e6e6e6'}}>
      <button className="button-export" onClick={() => exportToCSV(filteredData)}>Exportar CSV</button>
    <div className="styled-table-container">
      <table className="styled-table">
        <thead style={{ fontSize: 'medium'}}>
          <tr>
            <th style={{ cursor: 'pointer'}} onClick={() => handleSort('Project')}>Project</th>
            <th style={{ cursor: 'pointer'}} onClick={() => handleSort('Host')}>Hypervisor</th>
            <th style={{ cursor: 'pointer'}} onClick={() => handleSort('Nombre')}>Instancia</th>
            <th style={{ cursor: 'pointer'}} onClick={() => handleSort('Estado')}>Estado</th>
            <th>Owner</th>
            <th>Descripcion</th>
            <th>Redundancia</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.map((data, index) => (
            <tr key={index}>
              <td>{data.Project}</td>
              <td>{data.Host}</td>
              <td>{data.Nombre}</td>
              <td>{data.Estado}</td>
              <td>{getDescription2(data.Project)}</td>
              <td>{getDescription(data.Nombre)}</td>
              <td>{getDescription3(data.Nombre)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    </div>
  );
}

export default DataTable;
