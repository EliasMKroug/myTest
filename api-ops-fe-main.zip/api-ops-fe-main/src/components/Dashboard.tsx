import React from "react";
import Function from "./Function"; // Si es una función que retorna JSX

const Dashboard: React.FC = () => {
    return (
        <>
            {Function()} {/* Si `Function` retorna JSX */}
        </>
    );
};

export default Dashboard;