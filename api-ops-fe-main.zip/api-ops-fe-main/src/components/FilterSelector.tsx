import React from 'react';

interface FilterSelectorProps {
  filterType: string;
  handleFilterTypeChange: (event: React.ChangeEvent<HTMLSelectElement>) => void;
  searchTerm: string;
  handleSearchTermChange: (event: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => void;
  projects: string[];
  hypervisors: string[];
  estados: string[];
}

const FilterSelector: React.FC<FilterSelectorProps> = ({ 
  filterType, 
  searchTerm, 
  projects, 
  hypervisors, 
  estados, 
  handleFilterTypeChange, 
  handleSearchTermChange 
}) => {
  return (
    <div id='header2' style={{}}>
      <select value={filterType} onChange={handleFilterTypeChange}>
        <option value="">Seleccione filtro</option>
        <option value="Project">Project</option>
        <option value="Hypervisor">Hypervisor</option>
        <option value="Nombre">Instancia</option>
        <option value="Estado">Estado</option>
      </select>

      {filterType === 'Project' && (
        <select style={{ width: 250 }} value={searchTerm} onChange={handleSearchTermChange}>
          <option value="">Seleccione un project</option>
          {projects.map((project) => (
            <option key={project} value={project}>
              {project}
            </option>
          ))}
        </select>
      )}

      {filterType === 'Hypervisor' && (
        <select value={searchTerm} onChange={handleSearchTermChange}>
          <option value="">Seleccione un tenant</option>
          {hypervisors.map((hypervisor) => (
            <option key={hypervisor} value={hypervisor}>
              {hypervisor}
            </option>
          ))}
        </select>
      )}

      {filterType === 'Estado' && (
        <select value={searchTerm} onChange={handleSearchTermChange}>
          <option value="">Seleccione estatus</option>
          {estados.map((estado) => (
            <option key={estado} value={estado}>
              {estado}
            </option>
          ))}
        </select>
      )}

      {filterType === 'Nombre' && (
        <input
          type="text"
          value={searchTerm}
          onChange={handleSearchTermChange}
          placeholder="Buscar por nombre"
        />
      )}
    </div>
  );
}

export default FilterSelector;
