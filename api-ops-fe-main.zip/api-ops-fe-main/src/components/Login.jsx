// src/components/Login.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import '../assetss/css/Login.css';
import logo from '../assetss/img/Tasa-logo.png';

const Login = () => {
    const [form, setForm] = useState({ usuario: "", password: "" });
    const [error, setError] = useState(false);
    const [errorMsg, setErrorMsg] = useState("");
    const { login } = useAuth();
    const navigate = useNavigate();

    const manejadorSubmit = (e) => {
        e.preventDefault();
    };

    const manejadorChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    };

    const manejadorBoton = () => {
        const success = login(form.usuario, form.password);
        if (success) {
            setError(false);
            navigate("/dashboard");
        } else {
            setError(true);
            setErrorMsg("Credenciales incorrectas");
        }
    };

    return (
        <React.Fragment>
            <div className="wrapper fadeInDown" style={{ top: 0, left: 0, position: 'fixed'}}>
                <div id="formContent">
                    <div className="fadeIn first">
                        <br />
                        <img src={logo} width="100px" alt="User Icon" />
                        <br />
                        <br />
                    </div>
                    <form onSubmit={manejadorSubmit}>
                        <input
                            type="text"
                            className="fadeIn second"
                            name="usuario"
                            placeholder="Usuario"
                            onChange={manejadorChange}
                        />
                        <input
                            type="password"
                            className="fadeIn third"
                            name="password"
                            placeholder="Password"
                            onChange={manejadorChange}
                        />
                        <input
                            type="submit"
                            className="fadeIn fourth"
                            value="Log In"
                            onClick={manejadorBoton}
                        />
                    </form>
                    {error && (
                        <div className="alert alert-danger" role="alert">
                            {errorMsg}
                        </div>
                    )}
                </div>
            </div>
        </React.Fragment>
    );
};

export default Login;
