import React from 'react';

interface RegionSelectorProps {
  selectedRegion: string;
  selectedOption: string;
  handleRegionChange: (event: React.ChangeEvent<HTMLSelectElement>) => void;
  handleOptionChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

const RegionSelector: React.FC<RegionSelectorProps> = ({ 
  selectedRegion, 
  selectedOption, 
  handleRegionChange, 
  handleOptionChange 
}) => {
  return (
    <div id='header2'>
      <select value={selectedRegion} onChange={handleRegionChange}>
        <option value="">Seleccione un DC</option>
        <option value="cuyo">Cuyo</option>
        <option value="barracas">Barracas</option>
        <option value="republica">República</option>
      </select>

      {selectedRegion && (
        <div id='header2' style={{ marginTop: 10}}>
          {selectedRegion === 'cuyo' && (
            <>
              <input
                type="radio"
                id="cuyo-tc"
                name="location"
                value="cuyo-tc"
                checked={selectedOption === 'cuyo-tc'}
                onChange={handleOptionChange}
              />
              <label htmlFor="cuyo-tc">CUYO-TC</label>

              <input
                type="radio"
                id="cuyo-tt"
                name="location"
                value="cuyo-tt"
                checked={selectedOption === 'cuyo-tt'}
                onChange={handleOptionChange}
              />
              <label htmlFor="cuyo-tt">CUYO-TT</label>
            </>
          )}

          {selectedRegion === 'barracas' && (
            <>
              <input
                type="radio"
                id="brc-tc"
                name="location"
                value="brc-tc"
                checked={selectedOption === 'brc-tc'}
                onChange={handleOptionChange}
              />
              <label htmlFor="brc-tc">BRC-TC</label>

              <input
                type="radio"
                id="brc-tt"
                name="location"
                value="brc-tt"
                checked={selectedOption === 'brc-tt'}
                onChange={handleOptionChange}
              />
              <label htmlFor="brc-tt">BRC-TT</label>
            </>
          )}

          {selectedRegion === 'republica' && (
            <>
              <input
                type="radio"
                id="brc-tc-rpb"
                name="location"
                value="brc-tc-rpb"
                checked={selectedOption === 'brc-tc-rpb'}
                onChange={handleOptionChange}
              />
              <label htmlFor="brc-tc-rpb">BRC-TC</label>
            </>
          )}
        </div>
      )}
    </div>
  );
}

export default RegionSelector;