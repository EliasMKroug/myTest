import React from 'react';
import { Grid, Box, Typography, Select, MenuItem, FormControl, SelectChangeEvent, InputLabel  } from '@mui/material';

interface TotalSummaryProps {
  totalHyp: number;
  totalHypEstado: number;
  totalProjects2: number;
  totalProjectsTotal: Set<string>;
  filteredHyp: string[];
  selectedProject: string;
  isWarning: boolean;
  buttonColor: string;
  handleChange: (event: SelectChangeEvent<string>) => void;
}


const TotalSummary: React.FC<TotalSummaryProps> = ({
  totalHyp,
  totalHypEstado,
  totalProjects2,
  totalProjectsTotal,
  filteredHyp,
  selectedProject,
  isWarning,
  buttonColor,
  handleChange,
}) => {
  return (
    <Grid item xs={12} md={6}>
      <Box>
        <Typography variant="h5">Totales</Typography>

        {/* Fila para Hypervisors y botón */}
        <div className="check-row">
          <Typography variant="h6">Hypervisors: {totalHyp - totalHypEstado}</Typography>
          <button className="round-button" style={{ backgroundColor: buttonColor, cursor: 'default' }} />

          {isWarning ? (
            <FormControl style={{ backgroundColor: '#e6e6e6' }}>
              <Select
                value={filteredHyp[0] || ''} // Default value or first item
                displayEmpty
                MenuProps={{
                  PaperProps: {
                    style: {
                      maxHeight: 200, // Altura máxima del menú desplegable
                      width: 150, // Ancho del menú desplegable
                      color: 'black',
                    },
                  },
                  anchorOrigin: {
                    vertical: 'bottom',
                    horizontal: 'left',
                  },
                  transformOrigin: {
                    vertical: 'top',
                    horizontal: 'left',
                  },
                }}
              >
                {filteredHyp.map((hyp, index) => (
                  <MenuItem key={index} value={hyp}>
                    {hyp}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          ) : (
            <Typography style={{ padding: 12, color: 'white' }}>All hypervisors are ok</Typography>
          )}
        </div>

        {/* Fila para Projects y el desplegable */}
        <div className="check-row">
          <Typography>Projects: {totalProjects2}</Typography>
          <div className="select-container">
            <FormControl sx={{ width: '100%', marginLeft: 2, backgroundColor: '#e6e6e6' }}>
            <InputLabel id="project-select-label"></InputLabel>
              <Select
                id="project-select"
                value={selectedProject}
                onChange={handleChange}
                MenuProps={{
                  PaperProps: {
                    style: {
                      maxHeight: 350,
                      width: 250,
                      marginLeft: 200,
                      marginTop: -1,
                      backgroundColor: '#e6e6e6',
                    },
                  },
                  anchorOrigin: {
                    vertical: 'bottom',
                    horizontal: 'left',
                  },
                  transformOrigin: {
                    vertical: 'bottom',
                    horizontal: 'left',
                  },
                }}
                displayEmpty
              >
                <MenuItem value="" disabled>
              ----------------------------
            </MenuItem>
                {Array.from(totalProjectsTotal).map((project, index) => (
                  <MenuItem key={index} value={project} style={{ marginLeft: 2 }}>
                    {project}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </div>
        </div>
      </Box>
    </Grid>
  );
};

export default TotalSummary;
