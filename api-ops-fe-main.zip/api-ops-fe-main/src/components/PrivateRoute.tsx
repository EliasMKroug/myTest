// src/components/PrivateRoute.tsx
import React, { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

interface PrivateRouteProps {
  children: ReactNode;
}

const PrivateRoute = ({ children }: PrivateRouteProps) => {
    const { isAuthenticated } = useAuth();

    // Si no está autenticado, redirigir a la página de login
    if (!isAuthenticated) {
        return <Navigate to="/" />;
    }

    // Si está autenticado, renderizar la ruta protegida
    return <>{children}</>;
};

export default PrivateRoute;
