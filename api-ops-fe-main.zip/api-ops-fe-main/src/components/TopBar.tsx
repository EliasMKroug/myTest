import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemIcon from '@mui/material/ListItemIcon';
import Collapse from '@mui/material/Collapse';
import InboxIcon from '@mui/icons-material/MoveToInbox';
import MailIcon from '@mui/icons-material/Mail';
import Avatar from '@mui/material/Avatar';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import Link from '@mui/material/Link';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';

export default function ButtonAppBar() {
  const [drawerOpen, setDrawerOpen] = React.useState(false);
  const [openSubmenu, setOpenSubmenu] = React.useState(false);

  const handleDrawerToggle = () => {
    setDrawerOpen(!drawerOpen);
  };

  const handleSubmenuToggle = () => {
    setOpenSubmenu(!openSubmenu);
  };

  return (
    <Box>
    <Grid 
      container 
      alignItems="center" 
      justifyContent="space-between" 
      style={{ backgroundColor: '#1E90FF', padding: '5px', width: '100%',  top: 0, left: 0, position: 'fixed' }}
    >
      <Grid item>
        <IconButton
          size="medium"
          edge="start"
          color="inherit"
          aria-label="menu"
          sx={{ color: 'white', mr: 2 , marginLeft: 0.5 }}
          onClick={handleDrawerToggle} // Abre o cierra la barra lateral
        >
          <MenuIcon />
        </IconButton>
      </Grid>

      <Grid item>
        <img src="Tasa-logo2.png" alt="Logo izquierda" style={{ height: '80px' }} />
      </Grid>

      <Grid item xs>
        <h1 
          style={{ 
            color: 'white', 
            textAlign: 'center', 
            fontSize: '36px', 
            background: 'linear-gradient(to right, #1e3c72, #2a5298)', 
            WebkitBackgroundClip: 'text', 
            WebkitTextFillColor: 'white',
            margin: 0,
            fontWeight: 'bold'
          }}
        >
          T-CLOUD
        </h1>
      </Grid>

      <Grid item>
        <div style={{ display: 'flex', gap: '1px' }}>
          <img src="openstack.png" alt="Logo derecha 1" style={{ height: '80px' }} />
          <img src="rh.png" alt="Logo derecha 2" style={{ height: '80px' }} />
        </div>
      </Grid>
    </Grid>

    {/* <Drawer 
        anchor="left"
        open={drawerOpen}
        onClose={handleDrawerToggle}
        sx={{ '& .MuiDrawer-paper': { backgroundColor: '#9b9b9b', color:'white', marginLeft: 0 } }}
      >
        <Box sx={{ backgroundColor: '#388ee5', color: 'white', padding: 3.4, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Typography variant="h6" noWrap>
            Opciones
          </Typography>
          <IconButton color="inherit" onClick={handleDrawerToggle}>
            <MenuIcon />
          </IconButton>
        </Box>

        <Divider />

        <List>
          <ListItem button onClick={handleSubmenuToggle}>
            <ListItemIcon>
            </ListItemIcon>
            <ListItemText primary="Dashboards" sx={{ marginLeft: -7.5 }}/>
            {openSubmenu ? <ExpandLess sx={{ marginLeft: 5 }} /> : <ExpandMore sx={{ marginLeft: 5 }} /> }
          </ListItem>

          <Collapse in={openSubmenu} timeout="auto" unmountOnExit>
            <List component="div" disablePadding>
              <ListItem button sx={{ pl: 4 }}>
                <ListItemIcon>
                <Avatar src="rh-hat.png" sx={{ width: 24, height: 24, ml: -1.8 }} />
                </ListItemIcon>
                <ListItemText>
                  <Link href="https://operaciones-dashboard.apps.ocpws.cuyorh.tcloud.ar" color="inherit" underline="none" target="_blank" rel="noopener noreferrer" sx={{ marginLeft: -5 }}>
                    Ansible
                  </Link>
                </ListItemText>
              </ListItem>
              <ListItem button sx={{ pl: 4 }}>
                <ListItemIcon>
                <Avatar src="ws.png" sx={{ width: 24, height: 24, ml: -1.8 }} />
                </ListItemIcon>
                <ListItemText>
                  <Link href="/suboption2" color="inherit" underline="none" target="_blank" rel="noopener noreferrer" sx={{ marginLeft: -5 }}>
                    Whitestack
                  </Link>
                </ListItemText>
              </ListItem>
              <ListItem button sx={{ pl: 4 }}>
                <ListItemIcon>
                <Avatar src="ericsson.png" sx={{ width: 24, height: 24, ml: -1.8 }} />
                </ListItemIcon>
                <ListItemText>
                  <Link href="http://10.206.0.178/unica/Index.php" color="inherit" underline="none" target="_blank" rel="noopener noreferrer" sx={{ marginLeft: -5 }}>
                    NFVi6
                  </Link>
                </ListItemText>
              </ListItem>
            </List>
          </Collapse>
        </List>
      </Drawer> */}
  </Box>
);
}
