import React, { useState, useEffect } from 'react';
import { useGetAllData } from '../hooks/fetchData';
import { descriptions } from '../descriptions';
import '../assetss/css/Function.css';
import { useGetProjects,useGetHypervisors } from '../hooks/fetchData';
import TopBar from './TopBar'
import RegionSelector from './RegionSelector';
import FilterSelector from './FilterSelector';
import DataTable from './DataTable';
import TotalSummary from './TotalSummary';
import { Container, Grid, Box, Button, Typography, Select, MenuItem, FormControl, InputLabel, SelectChangeEvent } from '@mui/material';

interface JobData {
  Estado: string;
  Host: string;
  Nombre: string;
  Project: string;
  Estatus: string;
  Hypervisor: string;
}

const App = () => {
  const { cuyoTC, cuyoTT, brcTC, brcTT, getCuyoTC, getCuyoTT, getBrcTC, getBrcTT } = useGetAllData();
  const [selectedRegion, setSelectedRegion] = useState<string>('');
  const [selectedOption, setSelectedOption] = useState<string>('');
  const [dataToShow, setDataToShow] = useState<JobData[]>([]);
  const [dataToShow2, setDataToShow2] = useState<JobData[]>([]);
  const [dataToShow3, setDataToShow3] = useState<JobData[]>([]);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filterType, setFilterType] = useState<string>('');
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);
  const [projects, setProjects] = useState<string[]>([]);
  const [hypervisors, setHypervisors] = useState<string[]>([]);
  const [estados, setEstados] = useState<string[]>([]);
  const [totalVMs, setTotalVMs] = useState<number>(0);
  const [totalProjects, setTotalProjects] = useState<number>(0);
  const [totalHyp, setTotalHyp] = useState<number>(0);
  const [totalProjects2, setTotalProjects2] = useState<number>(0);
  const [totalProjectsTotal, setTotalProjectsTotal] = useState<Set<string>>(new Set());
  const { cuyoTCproj, cuyoTTproj, brcTCproj, brcTTproj, getCuyoTCproj, getCuyoTTproj, getBrcTCproj, getBrcTTproj } = useGetProjects();
  const { cuyoTChyp, cuyoTThyp, brcTChyp, brcTThyp, getCuyoTChyp, getCuyoTThyp, getBrcTChyp, getBrcTThyp } = useGetHypervisors();
  const [totalHypEstado, setTotalHypEstado] = useState<number>(0);
  const [totalHypEstatus, setTotalHypEstatus] = useState<number>(0);
  const [selectedProject, setSelectedProject] = useState<string>("");

  useEffect(() => {
    let data: JobData[] = [];
    let data2: JobData[] = [];
    let data3: JobData[] = [];
    
    if (selectedOption === 'cuyo-tc' && cuyoTC.length && cuyoTChyp.length && cuyoTCproj.length) {
      data = cuyoTC;
      data2 = cuyoTChyp;
      data3 = cuyoTCproj;
    } else if (selectedOption === 'cuyo-tt' && cuyoTT.length && cuyoTThyp.length && cuyoTTproj.length) {
      data = cuyoTT;
      data2 = cuyoTThyp;
      data3 = cuyoTTproj;
    } else if (selectedOption === 'brc-tc' && brcTC.length && brcTChyp.length && brcTCproj.length) {
      data = brcTC.filter(item => item.Host && !item.Host.includes('RPB')); // Filtra aquí
      data2 = brcTChyp.filter(item => item.Hypervisor && !item.Hypervisor.includes('RPB')); // Filtra aquí
      const projectFilters = (process.env.PROJECT_FILTERS || 'VDI').split(',');
      const projectRegex = new RegExp(projectFilters.join('|'));
      data3 = brcTCproj.filter(item => item.Project && !projectRegex.test(item.Project));
    } else if (selectedOption === 'brc-tt' && brcTT.length) {
      data = brcTT;
      data2 = brcTThyp;
      data3 = brcTTproj;
    } else if (selectedOption === 'brc-tc-rpb' && brcTC.length && brcTChyp.length && brcTCproj.length) {
      data = brcTC.filter(item => item.Host && !item.Host.includes('BRC'));
      data2 = brcTChyp.filter(item => item.Hypervisor && !item.Hypervisor.includes('BRC'));
      const projectFilters = (process.env.PROJECT_FILTERS || 'VDI').split(',');
      const projectRegex = new RegExp(projectFilters.join('|'));
      data3 = brcTCproj.filter(item => item.Project && projectRegex.test(item.Project));
    }

    setDataToShow(data);
    setDataToShow2(data2);
    setDataToShow3(data3);
    
    // Actualiza los filtros únicos
    if (data.length > 0) {
      if (filterType === 'Project') {
        if (selectedOption === 'brc-tc-rpb') {
          setProjects([...new Set(data.map(item => item.Project).filter(project => project && project.includes('VDI'))
          )].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })));
        } else {
          setProjects([...new Set(data.map(item => item.Project).filter(Boolean))].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })));
        }
      } else if (filterType === 'Hypervisor') {
        setHypervisors([...new Set(data.map(item => item.Host).filter(Boolean))].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })));
      } else if (filterType === 'Estado') {
        setEstados([...new Set(data.map(item => item.Estado).filter(Boolean))].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })));
      }
    }
    // Actualiza los totales
    setTotalVMs(data.length);
    setTotalProjects(new Set(data.map(item => item.Project)).size);
    setTotalProjects2(data3.length);
    setTotalProjectsTotal(new Set(data3.map(item => item.Project).sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }))));
    setTotalHyp(data2.length)
    setTotalHypEstado(data2.filter(item => item.Estado === 'down').length)
    setTotalHypEstatus(data2.filter(item => item.Estatus === 'disabled').length)

  }, [cuyoTC, cuyoTT, brcTC, brcTT, cuyoTChyp, cuyoTThyp, brcTChyp, brcTThyp, cuyoTCproj, cuyoTTproj, brcTCproj, brcTTproj, selectedOption, filterType]);

  const handleRegionChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedRegion(event.target.value);
    setSelectedOption('');
    setDataToShow([]);
    setDataToShow2([]);
    setDataToShow3([]);
    setFilterType('');
  };
  
  const handleOptionChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedOption(event.target.value);
    setDataToShow([]);
    setDataToShow2([]);
    setDataToShow3([]);
    setFilterType('');
  };

  const handleSearch = async () => {
    if (selectedOption === 'cuyo-tc') {
      await getCuyoTC();
      await getCuyoTChyp();
      await getCuyoTCproj();
    } else if (selectedOption === 'cuyo-tt') {
      await getCuyoTT();
      await getCuyoTThyp();
      await getCuyoTTproj();
    } else if (selectedOption === 'brc-tc') {
      await getBrcTC();
      await getBrcTChyp();
      await getBrcTCproj();
    } else if (selectedOption === 'brc-tt') {
      await getBrcTT();
      await getBrcTThyp();
      await getBrcTTproj();
    } else if (selectedOption === 'brc-tc-rpb') {
      await getBrcTC();
      await getBrcTChyp();
      await getBrcTCproj();
    }
  };

  const handleFilterTypeChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setFilterType(event.target.value);
    setSearchTerm('');
  };

  const handleSearchTermChange = (event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setSearchTerm(event.target.value);
  };

  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const sortedData = [...dataToShow].sort((a, b) => {
    if (sortConfig !== null) {
      const valueA = a[sortConfig.key as keyof JobData];
      const valueB = b[sortConfig.key as keyof JobData];

      if (valueA < valueB) {
        return sortConfig.direction === 'asc' ? -1 : 1;
      }
      if (valueA > valueB) {
        return sortConfig.direction === 'asc' ? 1 : -1;
      }
      return 0;
    }
    return 0;
  });

  const filteredData = sortedData.filter((data) => {
    if (filterType === 'Project') {
      if (searchTerm === "") {
        return data.Project.toLowerCase().includes(searchTerm.toLowerCase());  // Mostrar todos los proyectos si no hay filtro seleccionado
      }
      else {
        return data.Project.toLowerCase() === searchTerm.toLowerCase();
      }
    } else if (filterType === 'Hypervisor') {
      return data.Host.toLowerCase().includes(searchTerm.toLowerCase());
    } else if (filterType === 'Estado') {
      return data.Estado.toLowerCase().includes(searchTerm.toLowerCase());
    } else if (filterType === 'Nombre') {
      return data.Nombre.toLowerCase().includes(searchTerm.toLowerCase());
    }
    return true;
  });

  const getDescription = (nombre: string) => {
    for (const key in descriptions) {
      if (nombre.includes(key)) {
        return descriptions[key];
      }
    }
    return '';
  };

  const handleChange = (event: SelectChangeEvent<string>) => {
    setSelectedProject(event.target.value);
};

  
  const isWarning = totalHypEstado > 0; //|| totalHypEstatus > 0;
  const buttonColor = isWarning ? 'red' : 'green';

  const filteredHyp = dataToShow2
  .filter(item => item.Estado === 'down' || item.Estatus === 'disabled')
  .map(item => item.Hypervisor);

  return (
    <Box sx={{ flexGrow: 1 }}>
      <TopBar />

      <Container >
        <Grid container spacing={1} sx={{ mt: 1 }}>
        <div className="filter-container" style={{ marginLeft:-100, width: 400, borderRadius: 8 }}>
          <Grid item xs={12} md={6}>
            <RegionSelector
              selectedRegion={selectedRegion}
              selectedOption={selectedOption}
              handleRegionChange={handleRegionChange}
              handleOptionChange={handleOptionChange}
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <Box display="flex" sx={{ mt: 2 , ml:1}}>
              <Button variant="contained" onClick={handleSearch}>
                Buscar
              </Button>
            </Box>
          </Grid>

          <Grid item xs={12} md={6} mt={2}>
            <FilterSelector
              filterType={filterType}
              searchTerm={searchTerm}
              projects={projects}
              hypervisors={hypervisors}
              estados={estados}
              handleFilterTypeChange={handleFilterTypeChange}
              handleSearchTermChange={handleSearchTermChange}
            />
          </Grid>

          
          </div>
          </Grid>
          </Container>

          <Container>
          {dataToShow.length > 0 && (
            <div className='total-container' style={{ marginLeft: -110 , marginTop: -1}}>
            <Grid item xs={12} md={6}>
              <Box >
                <Typography variant="h5">Recursos actuales en uso:</Typography>
                <Typography>Instances: {totalVMs}</Typography>
                <Typography>Projects: {totalProjects}</Typography>
              </Box>
            </Grid>
            </div>
          )}
          </Container>

          <Container>
            {dataToShow.length > 0 && (
              <div className='check-container'>
                 <TotalSummary
            totalHyp={totalHyp}
            totalHypEstado={totalHypEstado}
            totalProjects2={totalProjects2}
            totalProjectsTotal={totalProjectsTotal}
            filteredHyp={filteredHyp}
            selectedProject={selectedProject}
            isWarning={isWarning}
            buttonColor={buttonColor}
            handleChange={handleChange}
            />
            </div>
            )}
          </Container>


          <Container>
          {filteredData.length > 0 && (
            <Grid item xs={12} md={6}>
              <DataTable filteredData={filteredData} handleSort={handleSort} />
            </Grid>
          )}
          </Container>
          
    </Box>
  );
};

export default App;
