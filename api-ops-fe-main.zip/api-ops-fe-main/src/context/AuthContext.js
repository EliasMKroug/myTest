// src/context/AuthContext.js
import React, { createContext, useState, useContext } from 'react';

// Crear un contexto para la autenticación
const AuthContext = createContext();

// Hook para usar el contexto
export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);

    // Función de login (esto sería más avanzado con un backend)
    const login = (username, password) => {
        if (username === 'admin' && password === 'operaciones') {
            setIsAuthenticated(true);
            return true;
        }
        else if (username === 'noc' && password === 'monitoreo') {
            setIsAuthenticated(true);
            return true;
        }
        return false;
    };

    // Función de logout
    const logout = () => {
        setIsAuthenticated(false);
    };

    return (
        <AuthContext.Provider value={{ isAuthenticated, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};
