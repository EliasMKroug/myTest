export const BASE_URL = 'https://api-ops-dashboard-operaciones-dashboard.apps.ocpws.cuyorh.tcloud.ar/openstack'
//export const BASE_URL = 'http://localhost:5000/openstack'