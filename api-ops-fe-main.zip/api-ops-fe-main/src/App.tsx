import React from 'react';
// import './assetss/css/App.css';
import './assetss/css/Function.css';

// import './App.css';
import 'bootstrap/dist/css/bootstrap.css';

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Login from './components/Login';
import Dashboard from './components/Dashboard';

import PrivateRoute from './components/PrivateRoute';
import { AuthProvider } from './context/AuthContext';
import Function from './components/Function';

function App() {
  return (
    <React.Fragment>
      <AuthProvider>
        <Router>
          <Routes>
          <Route path="/" element={<Login />}></Route>
          <Route path="/dashboard" element={<PrivateRoute><Dashboard /></PrivateRoute>}></Route>
          </Routes>
        </Router>
      </AuthProvider>
    </React.Fragment>
  );
}

export default App;