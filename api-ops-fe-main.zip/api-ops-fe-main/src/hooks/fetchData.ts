// hooks/fetchData.ts
import { useState } from 'react';
import { BASE_URL } from '../constants'

export const useGetAllData = () => {
  const [cuyoTC, setCuyoTC] = useState<any[]>([]);
  const [cuyoTT, setCuyoTT] = useState<any[]>([]);
  const [brcTC, setBrcTC] = useState<any[]>([]);
  const [brcTT, setBrcTT] = useState<any[]>([]);

  const fetchData = async (endpoint: string, setData: (data: any[]) => void) => {
    try {
      const response = await fetch(`${BASE_URL}/${endpoint}`);
      const data = await response.json();
      setData(data);
    } catch (error) {
      console.error(`Error fetching data from ${endpoint}:`, error);
    }
  };

  const getCuyoTC = () => fetchData('cuyo-tc', setCuyoTC);
  const getCuyoTT = () => fetchData('cuyo-tt', setCuyoTT);
  const getBrcTC = () => fetchData('brc-tc', setBrcTC);
  const getBrcTT = () => fetchData('brc-tt', setBrcTT);

  return { cuyoTC, cuyoTT, brcTC, brcTT, getCuyoTC, getCuyoTT, getBrcTC, getBrcTT };
};

export const useGetProjects = () => {
  const [cuyoTCproj, setCuyoTCproj] = useState<any[]>([]);
  const [cuyoTTproj, setCuyoTTproj] = useState<any[]>([]);
  const [brcTCproj, setBrcTCproj] = useState<any[]>([]);
  const [brcTTproj, setBrcTTproj] = useState<any[]>([]);

  const fetchData = async (endpoint: string, setData: (data: any[]) => void) => {
    try {
      const response = await fetch(`${BASE_URL}/${endpoint}/project`);
      const data = await response.json();
      setData(data);
    } catch (error) {
      console.error(`Error fetching data from ${endpoint}:`, error);
    }
  };

  const getCuyoTCproj = () => fetchData('cuyo-tc', setCuyoTCproj);
  const getCuyoTTproj = () => fetchData('cuyo-tt', setCuyoTTproj);
  const getBrcTCproj = () => fetchData('brc-tc', setBrcTCproj);
  const getBrcTTproj = () => fetchData('brc-tt', setBrcTTproj);

  return { cuyoTCproj, cuyoTTproj, brcTCproj, brcTTproj, getCuyoTCproj, getCuyoTTproj, getBrcTCproj, getBrcTTproj };
};

export const useGetHypervisors = () => {
  const [cuyoTChyp, setCuyoTChyp] = useState<any[]>([]);
  const [cuyoTThyp, setCuyoTThyp] = useState<any[]>([]);
  const [brcTChyp, setBrcTChyp] = useState<any[]>([]);
  const [brcTThyp, setBrcTThyp] = useState<any[]>([]);

  const fetchData = async (endpoint: string, setData: (data: any[]) => void) => {
    try {
      const response = await fetch(`${BASE_URL}/${endpoint}/hypervisors`);
      const data = await response.json();
      setData(data);
    } catch (error) {
      console.error(`Error fetching data from ${endpoint}:`, error);
    }
  };

  const getCuyoTChyp = () => fetchData('cuyo-tc', setCuyoTChyp);
  const getCuyoTThyp = () => fetchData('cuyo-tt', setCuyoTThyp);
  const getBrcTChyp = () => fetchData('brc-tc', setBrcTChyp);
  const getBrcTThyp = () => fetchData('brc-tt', setBrcTThyp);

  return { cuyoTChyp, cuyoTThyp, brcTChyp, brcTThyp, getCuyoTChyp, getCuyoTThyp, getBrcTChyp, getBrcTThyp };
};