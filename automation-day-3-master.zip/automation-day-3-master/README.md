Repositorio para todos los playbooks asociados con tareas de automatizacion del dia 3.


Tareas previstas dentro de este flujo:

* Eliminar pods completed (Vigencia de 1 dia, a menos de pedido especial).
* Eliminar pods en error (Vigencia a convenir).
* Pruning: https://docs.openshift.com/container-platform/4.12/applications/pruning-objects.html#pruning-deployments_pruning-objects
    - Deployments (Eliminar Replicasets dejando 5 de historial por deployment en caso de rollback).
    - Imagenes. -> Actualmente hay jobs corriendo en Ansible que ingresan a los nodos de prod y noprod, e ingresan a todos los nodos master para borrar manualmente las imagenes que no esten siendo usadas (crictl rmi), mientras que este comando apunta al registry local, y por ahi pudieramos estar dejando una que otra imagen que no este siendo usada.
    - Groups (Tema asociado con sincronizacion LDAP, se podria solicitar lista de grupos activos para estas tareas) No compara contra los groups creados localmente para OCP, es una limpieza que apunta a que un grupo no exista mas en el AD, y de alli SI NO LO CONSIGUE, lo limpiara en OCP. 
    - Builds (Son objetos que estan configurados con un source para la generacion de una imagen y recursos a partir de ella, por ahora no aplicaria un pruning ya que no se esta usando en los clusters)
* Maximo de pods por nodos workers.
* Instalacion de certificados.
* Configuracion de pull-secret para docker.io:
  Configurado. El secret de docker, al tener un flag para ejecutar su comando "oc create secret --docker-registry", contiene un cifrado adicional que al momento de extraer el "pull-secret" origina para tratar de actualizarlo añadiendole las nuevas credenciales para docker, genera un conflicto que no permite añadir el nuevo campo codificado o decodificado. Para detalles, añado link de la doc:

  https://docs.openshift.com/container-platform/4.12/openshift_images/managing_images/using-image-pull-secrets.html

Tarea opcional:

* Instalacion y migracion de Ansible Automation Platform (AAP).
