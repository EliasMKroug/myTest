Carpeta que contiene los cronjobs para realizar el pruning de ReplicaSets por cluster.

Tareas previstas dentro de este flujo:

* Eliminar ReplicaSets antiguos, dejando solo los ultimos 3 completed y 1 failed por deployment.

El cronjob generico, con los detalles que arriba se especifican es el siguiente:

* 01-cronjob-pruning-generic.yaml

Los cronjobs distintos al generico, son por requerimientos por parte del PaaS.