Carpeta que contiene los cronjobs para eliminar pods completed y en error.

Tareas previstas dentro de este flujo:

* Eliminar pods completed (Vigencia de 1 dia, a menos de pedido especial).
* Eliminar pods en error (Vigencia de 5 dias).

El cronjob generico, con las vigencias que arriba se especifican es el siguiente:

* 01-cronjob-cleaning.yaml

Los cronjobs distintos al generico, son por requerimientos por parte del PaaS.