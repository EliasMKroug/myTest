Documentacion del htpasswd identity provider:

 - https://docs.openshift.com/container-platform/4.12/authentication/identity_providers/configuring-htpasswd-identity-provider.html

Documentacion para poder tener soporte de ldap backend failover en la definicion de IDP
  El sig. workaround sugiere incorporar un haproxy entre oauth y ldaps servers
  https://access.redhat.com/solutions/5192321
