Detalles del repositorio para instalar el operador de unity e instanciarlo.

Documentacion v2.8.0: https://github.com/dell/csm-operator/blob/main/samples/storage_csm_unity_v280.yaml

Los ultimos 3 playbooks estan relacionados para interconectarse contra el unity. En el playbook numero 4, generamos el secret con los datos para autenticarse, en el playbook numero 5 añadimos dicho secret en el path spec.driver.authSecret y por ultimo, en el playbook 6, al generar la storageclass, esta debe estar asociada al mismo arrayID que se declaro para autenticarse en el secret del playbook numero 4.
