Info sobre nodos infra https://access.redhat.com/solutions/5034771
