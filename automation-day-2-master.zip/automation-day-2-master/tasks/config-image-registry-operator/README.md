![Alt text](image_registry_op_conf.png?raw=true "Title")
