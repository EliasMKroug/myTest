# La combinación Fluentd + Elasticsearch + Kibana = deprecated
Las plantillas de despliegues desarrolladas, despliegan el stack Fluentd + Elasticsearch + Kibana , sin embargo, es de notar que a partir de Openshift 4.11, esta combinación ya no es sugerida para nuevos despliegues. La siguiente nota de recomendación es citada en doc. de Openshift Logging : 

>For new installations, use Vector and LokiStack. Elasticsearch and Fluentd are deprecated and are planned to be removed in a future release.

# Openshift Logging stack
| La sig. documentación fué extraida de [blog/introduction-to-the-openshift-4-logging-stack](https://www.redhat.com/en/blog/introduction-to-the-openshift-4-logging-stack) | 
| ------ | 


The logging stack consists of five major components. These are:

* Event Router
* Fluentd
* Elasticsearch
* Kibana
* Curator

![Alt text](openshift-logging-topology.png?raw=true "Title")

## Event Router:

The operation begins with event processing. Event Router is a component that is deployed as a pod in the cluster, and its purpose is to ensure that OpenShift events are saved as logs. It does this by collecting any events occurring in the cluster, formatting them as JSON, and then handing them off to Fluentd. This allows processes, such as container creations, or failures when attaching a volume, to be reported in the cluster logs. Over time, this gives administrators a full record of what’s happening in the cluster.

## Fluentd:

The second part of the logging stack is the log collection. As mentioned before, this is performed by Fluentd. There are multiple moving parts involved with Fluentd, so it’s best to start the explanation from the ground up. If we think about a typical OpenShift cluster, there are several nodes hosting many pods, all managed by Kubernetes and OpenShift. These pods encapsulate containers, which are running processes that are usually outputting a steady stream of messages to places like STDOUT and STDERR. The messages printed are often helpful information like errors in Java or connection statuses for an application's HTTP requests. In the OpenShift logging stack, Fluentd comes configured to collect all of these logs, and the event logs produced by Event Router.

Fluentd is deployed as a daemonset, which allows for a Fluentd pod to be stationed on every node in the cluster. Because of this, each node can aggregate all the logs produced by containers on that node. This ensures that no matter where a pod is deployed, it’s logs will be picked up by Fluentd. In a typical configuration, container logs are located at /var/log/ inside a container, or are collected by journald running in the container. OpenShift comes pre-configured to aggregate these logs, and store them in the following directory on the node: /var/log/containers/POD-NAME_NAMESPACE-NAME_CONTAINER-NAME-CONTAINER-ID.log

It is via this directory that a Fluentd pod running on the node picks up the logs and prepares them for transport. Upon collection, Fluentd injects extra metadata into the log files such as the namespace, pod name, and container name where the logs originated. This makes it easier to search through the logs, sorting by pod name or namespace, for instance. After collection, Fluentd automatically handles the process of sending the logs to Elasticsearch pods in the cluster for storage and management. Because of its role in log collection, Fluentd pod failures are among the first things administrators should check if logs are not appearing in Kibana.

![Alt text](fluentd-topology.png?raw=true "Title")

## Elasticsearch:

The next and most central piece of the logging stack is Elasticsearch, the component where logs are stored. Elasticsearch usually consists of three pods, for high availability, each on a different node, for redundancy. These pods are responsible for long term storage of the logs, and things like RBAC policy that protect logs from being read by unauthorized users. The Elasticsearch deployments are configured with their own special storage volume so that they have enough disk space to hold as many logs as the cluster needs. Elasticsearch intakes logs from Fluentd and formats them in what are called “indices”, which are labeled a couple ways. Indices labeled .operations.<date> are indices that hold records of cluster events collected by Event Router. Indices labeled .project.<project_name> are indices that hold logs from containers corresponding to that project, respectively. While it is possible to manually obtain Elasticsearch logs via a REST api, it is a best practice to view them using Kibana.

## Kibana:

At the end of the chain of operations that comprise the logging stack is Kibana, a component that provides a GUI to view the logs. In a typical cluster, Kibana exists as a single pod that serves web pages via a URL provided by an OpenShift route. Under the hood, when a user interacts with the Kibana GUI, the pod issues API requests to the Elasticsearch pods to retrieve and display the logs in the indices. To locate the Kibana URL, an administrator can run oc get routes -n openshift-logging. When the Kibana URL is entered into a browser, the administrator can log into a GUI which presents the logs in a visual format and provides mechanics for sorting and searching the logs.

## Curator:

The final component of the logging stack is Curator, which is responsible for cluster log rotation. Log rotation is the act of periodically deleting older logs from a log store in order to save on disk space. Curator exists as a single pod in the openshift-logging namespace and is configured as a cron job. At the time dictated by the cron job, the curator pod is spun up and will perform deletion actions as determined by its mounted configmap. For instance, Curator’s configmap can be set up so that Curator will delete any logs that are more than seven days old. This prevents older logs from weighing down the disks underpinning Elasticsearch.

