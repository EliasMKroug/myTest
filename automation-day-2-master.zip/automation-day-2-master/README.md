# Automatizacion del dia 2. Tareas de configuración mínima de un cluster Openshift

## Versiones de openshift para las cuales ha sido probado : 
- 4.12
- 4.14

## Tareas que se despliegan usando estos playbooks

- **Operador Dell-csm** (_tasks/dell-csm-operator/config-unity-operator.yaml_):
  
  tag: dell_csm_operator
  - Instalación de operador dell-csm-operator. Ver versiones soportadas en _main.yaml_
  - Configuración de instancia unity acorde a versión de operador, y con acceso a unity ubicado en mismo site.

- **Config Operador Image-registry** (_tasks/config-image-registry-operator/registry-storage-config.yaml_):
  
  tag: config_img_registry_operator
  - Configuracion de tolerations para correr en nodos infra
  - Configuracion de instancia para almacenamiento en S3, o PVC según se solicite

- **Creacion de MachineConfigPools** (_tasks/MachineConfigPools/config-machineConfigPools.yaml_):
  
  tag: mcp_config
  - Creación de machine config pools basado en los roles especificados

- **Config. de MachineConfig para ntp sync** (_tasks/NTP-Configuration/config-ntp.yaml_):
  
  tag: machineConfig_ntp
  - Creación de machineConfig con configuración de NTP basado en los roles especificados
  - Los ntp servers de determinan basado en el site del cluster

- **Config. de KubeletConfig para Max. Cdad de pods por worker** (_tasks/max-pods-per-worker/max-pods-per-worker.yaml_):
  
  tag: max_pod_per_worker
  - Configuración de kubelet para rol worker

- **Config. de image reposotories** (_tasks/..._):

- **Config. de proxy global** (_tasks/..._):

- **Install/Config operadores elasticsearch-operator , openshift-logging** (_tasks/..._):

- **Install/Config Red Hat Single Sign-On Operator** (_tasks/..._):

- **Config oauth identity providers** (_tasks/..._):

- **Config jobs para sincronización de grupos** (_tasks/..._):

- **Config de Ingress router node_rol/replicas/certificate** (_tasks/..._):


## Corriendo tareas de dia2 desde su entorno WSL

Ej. para el caso de cluster ` ocpws-cuyorh`, encontrará el archivo de config. para este en ` cluster_conf/ocpws-cuyorh.yaml`.
Para ejecutar las tareas de día 2 para este cluster deberá usar : 

`$ ansible-playbook main.yaml -e cluster_conf=cluster_conf/ocpws-cuyorh.yaml --ask-vault-pass ` 

O si lo prefiere, puede almacenar la clave en un archivo de manera de evitar la peticion

`$ ansible-playbook main.yaml -e cluster_conf=cluster_conf/ocpws-cuyorh.yaml --vault-password-file mi_archivo_de_clave  ` 

La clave vault usada, es aquella que comienza con "M", y finaliza con ".."

Se dispone de una forma para correr solo una tarea específica, sin necesidad de activar esta, y desactivar las demas. Debe usar la característica de ansible : "tags" . Cada tarea se encuentra con un "tag" específico, de manera que parar ejecutar solamente la tarea de configuracion para max. cdad. de pods por worker, desde main.yaml, se observa que esta tarea posee el tag "max_pod_per_worker". Entonces.. podra ejecutarla usando : 

`$ ansible-playbook main.yaml -e cluster_conf=cluster_conf/ocpws-cuyorh.yaml --vault-password-file mi_archivo_de_clave --tags "max_pod_per_worker" ` 

Notar que en el ejemplo anterior, la tarea relacionada a max pods por worker, se encuentra controlada por la posibilidad de hacer pausas en MachineConfigPools. De manera que si desea que esta pausa sea efectiva cuando usa tags, debera ademas incluir los tags corresondientes . Ej.:
`$ ansible-playbook main.yaml -e cluster_conf=cluster_conf/ocpws-cuyorh.yaml --vault-password-file mi_archivo_de_clave --tags "mcp_pause,max_pod_per_worker" ` 


