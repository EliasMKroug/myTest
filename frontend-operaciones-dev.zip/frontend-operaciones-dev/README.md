Misc:

green ansible: #6ec664
red ansible: #a30000
green trilio: #36581f #4f7138
red trilio: #bd3942
selected green: #528F42
selected red: #bd3942

podman rmi localhost/frontend-operaciones && podman build -f botDockerfile . -t localhost/frontend-operaciones && podman tag localhost/frontend-operaciones operacionredcloud/frontend-dashboard:latest && podman push operacionredcloud/frontend-dashboard:latest