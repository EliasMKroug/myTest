import { useEffect, useState } from 'react'
import { API_BASE_URL } from '../constants'
import { transformAnsibleData } from '../utils/ansible'
import { transformTrilioData } from '../utils/trilio'

export const useGetApiData = (site: string, metric: string) => {
  const [data, setData] = useState<any>()

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/${metric}/${site}`)
        const responsedata = await response.json()
        setData(responsedata)
      } catch (error) {
        console.error('Unable to fetch data:', error)
      }
    }
    fetchData()
  }, [setData])

  return data
}

export const useGetAllData = () => {
  const [isLoading, setLoading] = useState<boolean>(true)
  const [ansibleCuyo, setAnsibleCuyo] = useState<any>()
  const [ansibleBrc, setAnsibleBrc] = useState<any>()
  const [trilioCuyo, setTrilioCuyo] = useState<any>()
  const [trilioBrc, setTrilioBrc] = useState<any>()

  useEffect(() => {
    const fetchData = async () => {
      try {
        const responses = await Promise.all([fetch(`${API_BASE_URL}/ansible/cuyo`),fetch(`${API_BASE_URL}/ansible/brc`) ,fetch(`${API_BASE_URL}/trilio/cuyo`),fetch(`${API_BASE_URL}/trilio/brc`)])
        //
        const responsesData = responses.map(async (resp, index) => {
          const data = await resp.json();
          if (index in [0,1]){
            const cluster = index===0 ? 'cuyo': 'brc'
            const transpiledData = transformAnsibleData(data, cluster)
            return transpiledData;
          }
          else{
            const transpiledData = transformTrilioData(data)
            return transpiledData;
          }
        })
        setAnsibleCuyo(await responsesData[0])
        setAnsibleBrc(await responsesData[1])
        setTrilioCuyo(await responsesData[2])
        setTrilioBrc(await responsesData[3])
        setLoading(false)
      } catch (error) {
        console.error('Unable to fetch data:', error)
      }
    }
    fetchData()
  }, [])

  return {isLoading, ansibleCuyo, ansibleBrc, trilioCuyo, trilioBrc} 
}
