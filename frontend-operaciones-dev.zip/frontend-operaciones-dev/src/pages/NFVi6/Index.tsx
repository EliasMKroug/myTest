import './Index.css';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import { useState } from 'react';



const NFVi6: React.FC = () => {
    const [kind, setKind] = useState('vapp');
    const handleChangeKind = (event: React.ChangeEvent<HTMLInputElement>) => {
        setKind((event.target as HTMLInputElement).value);
    };

    const [dc, setDatacenter] = useState('mpc');
    const handleChangeDC = (event: React.ChangeEvent<HTMLInputElement>) => {
        setDatacenter((event.target as HTMLInputElement).value);
    };
    
    const controlPropsKind = (item: string) => ({
        checked: kind === item,
        value: item,
        name: 'color-radio-button-demo',
        inputProps: { 'aria-label': item },
    });

    const WhiteRadioKind = (radioValue: string) => {
        return (
            <Radio {...controlPropsKind(radioValue)} sx={{color: 'white'}} />
        );
    }

    const controlPropsDC = (item: string) => ({
        checked: dc === item,
        value: item,
        name: 'color-radio-button-demo',
        inputProps: { 'aria-label': item },
    });

    const WhiteRadioDC = (radioValue: string) => {
        return (
            <Radio {...controlPropsDC(radioValue)} sx={{color: 'white'}} />
        );
    }

    return (
        <>
            <div>
                <FormControl sx={{backgroundColor: 'rgb(109, 106, 110)', width: '377px', textAlign: 'center', padding:'10px 25px 10px 25px'}}>
                    <FormLabel id="dc-options" sx={{color: 'white'}}>Datacenter:</FormLabel>
                    <RadioGroup
                        row
                        aria-labelledby="dc-options"
                        name="dc-options-group"
                        value={dc}
                        onChange={handleChangeDC}
                    >
                        <FormControlLabel control={WhiteRadioDC("mpc")} label="Mar del Plata (MPC)" />
                        <FormControlLabel control={WhiteRadioDC("gpz")} label="Mendoza (GPZ)" />
                    </RadioGroup>
                </FormControl>
            </div>
            <div>
                <FormControl sx={{backgroundColor: 'rgb(109, 106, 110)', width: '377px', textAlign: 'center', padding:'10px 25px 10px 25px'}}>
                    <FormLabel id="vnf-options" sx={{color: 'white'}}>Consulta por VNF:</FormLabel>
                    <RadioGroup
                        row
                        aria-labelledby="vnf-options"
                        name="vnf-options-group"
                        value={kind}
                        onChange={handleChangeKind}
                    >
                        <FormControlLabel control={WhiteRadioKind("vapp")} label="vAPP" />
                        <FormControlLabel control={WhiteRadioKind("vms")} label="VMs" />
                        <FormControlLabel control={WhiteRadioKind("compute")} label="Compute" />
                        <FormControlLabel control={WhiteRadioKind("tenant")} label="Tenant" />
                    </RadioGroup>
                </FormControl>
            </div>
            <div>
                <a>{[dc, kind]}</a>
            </div>
        </>
        
    )
}
export default NFVi6