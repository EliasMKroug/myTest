import { useEffect, useState } from 'react';
import Resume from '../../components/Resume'
import AnsibleAccordion from '../../components/AnsibleAccordion'
import './Main.css';
import Notification from '../../components/Notification';
import  { AlertColor } from '@mui/material/Alert';
import { useGetAllData } from '../../hooks/fetchData';
import TrilioAccordion from '../../components/TrilioAccordion';

export const Main = () => {

    const datum = useGetAllData();
    const [notificationMessage, setMessage]= useState('')
    const [typeNotif, setTypeNotif] = useState<AlertColor>('info')
    useEffect(()=>{
      if(!datum.isLoading){
        if(datum.ansibleBrc.resume.failed>0 || datum.ansibleCuyo.resume.failed>0 || datum.trilioCuyo.resume.failed>0 || datum.trilioBrc.resume.failed>0)
        // 
        {
          setMessage('Hay procesos con errores desde el dia de ayer.')
          setTypeNotif('error')
        }
        else{
          setMessage('Todos los procesos corrieron bien desde ayer.')
          setTypeNotif('success')
        }
      }
    },[datum])
  
    return (
      <>
        {datum.isLoading ? <></> : <Notification type={typeNotif} message={notificationMessage}/>}
        <Resume/>
        {datum.isLoading ? <></> : <AnsibleAccordion title='Ansible' cuyo={datum.ansibleCuyo.data} brc={datum.ansibleBrc.data}/> }
        {/* {datum.isLoading ? <></> : <TrilioAccordion title='Trilio' cuyo={datum.trilioCuyo.data} brc={datum.trilioBrc.data}/> } */}
      </>
    )
}