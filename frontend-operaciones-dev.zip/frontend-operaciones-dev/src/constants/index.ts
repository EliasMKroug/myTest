export const BASE_URL = 'http://api-gateway-dashboard-service-operaciones-dashboard.apps.ocpacm.cuyorh.tcloud.ar'
export const API_BASE_URL = BASE_URL+'/api'
