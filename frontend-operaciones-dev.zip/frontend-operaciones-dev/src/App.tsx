import {
  BrowserRouter as Router,
  Route,
  Routes
} from "react-router-dom";
import { Main } from './pages/Main/Main';
import NFVi6 from './pages/NFVi6/Index';

const App = () => {
  return (
      <Router>
        <Routes>
          <Route path="/" index element={<Main />} />
          <Route path="/nfvi6" element={<NFVi6 />}/>
        </Routes>
    </Router>
  );
}

export default App;
