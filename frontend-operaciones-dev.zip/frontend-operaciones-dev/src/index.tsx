import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import TopBar from './components/TopBar';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);
root.render(
  <React.StrictMode>
    <div className="background">
      <TopBar/>
      <div className="margined">
        <App/>
      </div>
    </div>
  </React.StrictMode>
);