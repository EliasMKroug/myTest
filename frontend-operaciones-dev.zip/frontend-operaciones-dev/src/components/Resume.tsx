import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Grid2 from '@mui/material/Unstable_Grid2';
import ComplexDonut from './ComplexDonut';
import { useState } from 'react';
import * as React from 'react';

const Resume: React.FC = () => {
    const [expandedState, setExpandedState] = useState(true)
    
    return (
      <Accordion expanded={expandedState}
        onClick={() => setExpandedState(!expandedState)}
        style={{
          backgroundColor: '#6D6A6E',
          borderRadius:'5px',
          color:'white',
          marginTop:'70px'
        }}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography>Resumen</Typography>
        </AccordionSummary>
        <AccordionDetails style={{backgroundColor: '#6D6A6E'}}>
            <Grid2 container spacing={2} minHeight={200}>
                <Grid2 xs={6} xl={3} display="flex" justifyContent="center" alignContent="center">
                    <ComplexDonut site='cuyo' metric='ansible'/>
                </Grid2>
                <Grid2 xs={6} xl={3} display="flex" justifyContent="center" alignContent="center">
                    <ComplexDonut site='brc' metric='ansible'/>
                </Grid2>
                <Grid2 xs={6} xl={3} display="flex" justifyContent="center" alignContent="center">
                    <ComplexDonut site='cuyo' metric='trilio'/>
                </Grid2>
                <Grid2 xs={6} xl={3} display="flex" justifyContent="center" alignContent="center">
                    <ComplexDonut site='brc' metric='trilio'/>
                </Grid2>
            </Grid2>
        </AccordionDetails>
      </Accordion>
  );
}
export default Resume