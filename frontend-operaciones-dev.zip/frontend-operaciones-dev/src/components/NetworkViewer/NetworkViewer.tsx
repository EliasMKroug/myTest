import * as React from 'react';

const NetworkViewer: React.FC = () => {

  return (
    <></>
  );
}

export default NetworkViewer