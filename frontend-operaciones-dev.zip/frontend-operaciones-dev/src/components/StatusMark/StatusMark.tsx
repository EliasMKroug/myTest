import Tooltip, { tooltipClasses, TooltipProps } from '@mui/material/Tooltip';
import React from 'react';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import DisabledByDefaultRoundedIcon from '@mui/icons-material/DisabledByDefaultRounded';
import { styled } from '@mui/material/styles';

interface MarkData {
  status: 0 | 1;
  text: string;
  action: string;
}

const StyledTooltip = styled(({ className, ...props }: TooltipProps) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: 'white',
    color: 'rgba(0, 0, 0, 0.87)',
    boxShadow: theme.shadows[1],
    fontSize: 13,
  },
}));

export const StatusMark: React.FC<MarkData> = ({status, text, action}) => {

  const handler = () => {
    window.open(action);
  }

  return (
    <StyledTooltip title={text} placement='top'>
      {status === 1
          ? <CheckBoxIcon sx={{color:'#37bd3d', cursor: 'pointer'}} onClick={handler}/>
          : <DisabledByDefaultRoundedIcon sx={{color:'#f33939', cursor: 'pointer'}} onClick={handler}/>
      }
    </StyledTooltip>
  )
}