import * as React from 'react';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import { StatusMark } from './StatusMark/StatusMark';

// | 'results'
interface Column {
  id: 'name' | 'next_run' | 'description' | 'last_results' ;
  label: string;
  minWidth?: number;
  align?: 'right';
  format?: (value: number) => string;
}

const columns: readonly Column[] = [
  { id: 'name', label: 'Nombre', minWidth: 170 },
  { id: 'next_run', label: 'Vuelve a correr', minWidth: 170 },
  {
    id: 'description',
    label: 'Descripcion',
    minWidth: 170,
  },
  {
    id: 'last_results',
    label: 'Ultimos resultados',
    minWidth: 170,
  }
];

interface RowData {
  cluster: string;
  name: string;
  next_run: string;
  description: string;
  last_results: any[];
  results: [any];
}
interface TableProps{
  data: RowData[]
}

const StickyHeadTable: React.FC<TableProps> = ({data}) => {
  const _data = data.map(row => {
    const lastResults = row.results.map(result => {
      return <StatusMark
             status={result.status === 'successful'? 1 : 0}
             text={`Finalizo a las: ${result.finished}`}
             action={`https://tower.${row.cluster}rh.tcloud.ar/#/jobs/${result.type==='workflow_job'? 'workflow' : 'playbook'}/${result.id}`}
            />
      })
    row.last_results = lastResults
    return row
  })
  console.log(_data)
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(25);

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  return (
    <Paper sx={{ width: '100%', overflow: 'hidden', backgroundColor: 'rgb(109, 106, 110)' }}>
      <TableContainer sx={{ maxHeight: 500, backgroundColor: 'rgb(109, 106, 110)' }}>
        <Table stickyHeader aria-label="sticky table" sx={{ backgroundColor: 'rgb(109, 106, 110)'}}>
          <TableHead sx={{ backgroundColor: 'rgb(109, 106, 110)'}}>
            <TableRow sx={{ backgroundColor: 'rgb(109, 106, 110)'}}>
              {columns.map((column) => (
                <TableCell
                  key={column.id}
                  align={column.align}
                  style={{ minWidth: column.minWidth,color:'white', backgroundColor: 'rgb(109, 106, 110)' }}
                >
                  {column.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {_data
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((row, thisindex) => {
                return (
                  <TableRow hover role="checkbox" tabIndex={-1} key={thisindex}>
                    {columns.map((column) => {
                      const value = row[column.id];
                      return (
                        <TableCell key={column.id} align={column.align} sx={{color:'white'}}>
                          {column.id==='last_results' ? <p>{value}</p> : value}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                );
              })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[25, 100]}
        component="div"
        count={data.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
        sx={{color:'white'}}
      />
    </Paper>
  );
}

export default StickyHeadTable