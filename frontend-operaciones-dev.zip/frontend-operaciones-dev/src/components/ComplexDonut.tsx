import DonutChart from './DonutChart';
import {  useGetApiData } from '../hooks/fetchData';
import { transformAnsibleData } from '../utils/ansible'
import { transformTrilioData } from '../utils/trilio'
import { useEffect, useState } from 'react';
import Skeleton from '@mui/material/Skeleton';

interface Props{
    site: string
    metric: string
}

const ComplexDonut: React.FC<Props> = ({site, metric}) => {
    const [isLoading, setLoading] = useState(true)
    const [chartData, setData] = useState<any>()
    const metricData = useGetApiData(site,metric)
    
    useEffect(()=>{
        if(metricData) {
            setLoading(false)
            let _data: any
            if(metric==='ansible'){
                _data = transformAnsibleData(metricData,site)
            }
            else{
                _data = transformTrilioData(metricData)
            }
            setData(_data)
        }
    },[metricData, metric])

    const graph = [
        {
          label: 'Completados',
          value: isLoading ? 0 : chartData.resume.success,
          isEmpty: isLoading ? true : chartData.resume.success===0
        },
        {
          label: 'Fallados',
          value: isLoading ? 0 :chartData.resume.failed,
          isEmpty: isLoading ? true : chartData.resume.failed===0
        }
    ];

    const colors = ['#528F42','#bd3942'];
    // if(site=='brc' && metric=='trilio' && !isLoading) console.log(chartData)
    return (
        <>
            { isLoading ? 
            <>
                <Skeleton variant="text" width={100} height={25} animation="pulse"/>
                <Skeleton variant="circular" width={186} height={186} animation="pulse"/>
            </>
            : 
            <>
                <p style={{color:'white'}}>{metric[0].toUpperCase()+metric.slice(1)} {site[0].toUpperCase()+site.slice(1)} :</p>
                <DonutChart data={graph} width={200} height={200} legend={false} colors={colors} strokeColor="white"/>
            </>
            }
        </>
  );
}
export default ComplexDonut