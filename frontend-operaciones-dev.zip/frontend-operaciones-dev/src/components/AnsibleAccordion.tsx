import * as React from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import AnsibleTable from './AnsibleTable';

interface AccordionProps {
    title: String
    cuyo: any,
    brc: any
}

const AnsibleAccordion: React.FC<AccordionProps> = ({title, cuyo, brc}) => {
  const mergedData = cuyo.wjobs.concat(cuyo.jobs,brc.wjobs,brc.jobs)
  return (
      <Accordion 
        style={{
          backgroundColor: '#6D6A6E',
          borderRadius:'5px',
          color:'white',
          margin:'10px'
        }}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
            <Typography>{title}</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <AnsibleTable data={mergedData}/>
            </Typography>
          </AccordionDetails>
      </Accordion>
  );
}
export default AnsibleAccordion