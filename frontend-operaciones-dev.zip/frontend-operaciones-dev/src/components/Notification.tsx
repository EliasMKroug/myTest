import * as React from 'react';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert, { AlertColor, AlertProps } from '@mui/material/Alert';
import Slide, { SlideProps } from '@mui/material/Slide';

type TransitionProps = Omit<SlideProps, 'direction'>;

const fromTop = (props: TransitionProps) => {
  return <Slide {...props} direction="down" />;
}

const Alert = React.forwardRef<HTMLDivElement, AlertProps>(function Alert(
  props,
  ref,
) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

interface NotifProps{
  message: string
  type: AlertColor
}

const Notification: React.FC<NotifProps> = ({message,type}) => {
  const [open, setOpen] = React.useState(true);

  const handleClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpen(false);
  };

  return (
      <Snackbar 
        anchorOrigin={{vertical:'top', horizontal:'center'}}
        open={open} 
        onClose={handleClose} 
        TransitionComponent={fromTop}
        sx={{marginTop:'50px'}}
        >
        <Alert onClose={handleClose} severity={type} sx={{ width: '100%' }}>
          {message}
        </Alert>
      </Snackbar>
  );
}

export default Notification