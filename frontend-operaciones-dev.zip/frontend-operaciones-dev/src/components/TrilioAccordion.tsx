import * as React from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import TrilioTable from './TrilioTable';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import DisabledByDefaultRoundedIcon from '@mui/icons-material/DisabledByDefaultRounded';

interface AccordionProps {
    title: String
    cuyo: any,
    brc: any
}

const TrilioAccordion: React.FC<AccordionProps> = ({title, cuyo, brc}) => {
  const cuyoData: { name: string; next_run: any; site: string; last_results: any; }[] = [];
  Object.entries(cuyo).forEach(([key,value]) => {
    cuyoData.push({
      name: key,
      next_run: cuyo[key][cuyo[key].length-1].startedAt,
      site: 'CUYO',
      last_results: cuyo[key].slice(cuyo[key].length-10,cuyo[key].length).map((obj:any) => obj.status === 'Available'? <CheckBoxIcon sx={{color:'#37bd3d'}}/> : <DisabledByDefaultRoundedIcon sx={{color:'#f33939'}}/>)
    })
  })
  const brcData: { name: string; next_run: any; site: string; last_results: any; }[] = [];
  Object.entries(brc).forEach(([key,value]) => {
    brcData.push({
      name: key,
      next_run: brc[key][brc[key].length-1].startedAt,
      site: 'BRC',
      last_results: brc[key].slice(brc[key].length-10,brc[key].length).map((obj:any) => obj.status === 'Available'? <CheckBoxIcon sx={{color:'#37bd3d'}}/> : <DisabledByDefaultRoundedIcon sx={{color:'#f33939'}}/>)
    })
  })
  
  return (
      <Accordion 
        style={{
          backgroundColor: '#6D6A6E',
          borderRadius:'5px',
          color:'white',
          margin:'10px'
        }}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
            <Typography>{title}</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <TrilioTable data={cuyoData.concat(brcData)}/>
            </Typography>
          </AccordionDetails>
      </Accordion>
  );
}
export default TrilioAccordion