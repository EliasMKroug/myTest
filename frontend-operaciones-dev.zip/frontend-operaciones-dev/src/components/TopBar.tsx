import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import { Button } from '@mui/material';

export default function ButtonAppBar() {
  return (
    <Box sx={{ flexGrow: 1}}>
      <AppBar position="static" style={{backgroundColor:'#0066ff'}}>
        <Toolbar>
          {/* <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="menu"
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton> */}
          { window.location.href.indexOf('/nfvi6') > 0 ?
            <Button 
              variant="contained"
              onClick={event =>  window.location.href='/'}>
              Inicio
            </Button> :
            <Button 
              variant="contained"
              onClick={event =>  window.location.href='/nfvi6'}>
              NFVi6
            </Button>
          }          
          <div style={{ flexGrow: 1 }}>
            <img src='/logo-tasa.png' alt='logo-tasa'/>
          </div>
        </Toolbar>
      </AppBar>
    </Box>
  );
}