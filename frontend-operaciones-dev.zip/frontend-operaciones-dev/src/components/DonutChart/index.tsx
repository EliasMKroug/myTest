import DonutChart from './DonutChart';
export default DonutChart;