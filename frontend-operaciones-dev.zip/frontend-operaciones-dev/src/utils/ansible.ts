export const transformAnsibleData = (data: any, cluster: string) => {
    const newData = {
        resume:{
            success: 0,
            failed: 0,
        },
        data: {}
    };

    newData.data=data.data
    
    data.data.jobs.forEach((job: any)=> {
        job.cluster=cluster
        if(job.results[0].status==='successful') newData.resume.success++
        else if (job.results[0].status!=='successful') newData.resume.failed++
    })

    data.data.wjobs.forEach((job: any)=> {
        job.cluster=cluster
        if(job.results[0].status==='successful') newData.resume.success++
        else if (job.results[0].status!=='successful') newData.resume.failed++
    })

    return newData
}
