const getToday = () => {
    const today = new Date();
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    const yyyy = today.getFullYear();
    return yyyy + '-' + mm + '-' + dd;
}

export const transformTrilioData = (data: any) => {
    const newData = {
        resume:{
            success: 0,
            failed: 0,
        },
        data: {}
    };
    
    const reduced = data.data.reduce((r: any, a:any) => {
        r[a.namespace] = r[a.namespace] || [];
        r[a.namespace].push(a);
        return r;
    }, Object.create(null))

    newData.data=reduced

    data.data.forEach((bkp: any) => {
        const _datebkp=bkp.startedAt
        if(_datebkp.startsWith(getToday())){
            if(bkp.status==='Available') newData.resume.success++
            else if(bkp.status!=='Available') newData.resume.failed++
        }
    })

    return newData
}
