echo "----------------> Job started."
echo "----------------> Removing old images."
podman rmi localhost/frontend-operaciones
echo "----------------> Set HTTP Proxy."
export HTTP_PROXY=http://10.166.15.178:8080
export HTTPS_PROXY=http://10.166.15.178:8080
export http_proxy=http://10.166.15.178:8080
export https_proxy=http://10.166.15.178:8080
echo "----------------> Build image with new files."
podman build . -t localhost/frontend-operaciones
echo "----------------> Tag new image."
podman tag localhost/frontend-operaciones operacionredcloud/frontend-dashboard:latest
echo "----------------> Push new images to docker."
podman push operacionredcloud/frontend-dashboard:latest
echo "----------------> Unset HTTP Proxy."
unset HTTP_PROXY
unset HTTPS_PROXY
unset http_proxy
unset https_proxy
echo "----------------> Job end."