The changelog has moved `here <https://github.com/ansible-collections/ansible.netcommon/blob/main/CHANGELOG.rst>`_
