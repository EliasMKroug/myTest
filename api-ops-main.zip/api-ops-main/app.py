import requests
import json
import urllib3
import os
from decouple import config
from flask import Flask, jsonify, request
from flask_cors import CORS

urllib3.disable_warnings()

app = Flask(__name__)
CORS(app)

class OpenStackClient:
    def __init__(self, auth_url, id, secret):
        self.auth_url = auth_url
        self.id = id
        self.secret = secret
        self.token = None
        self.nova_url = None
        self.neutron_url = None
        self.glance_url = None

    def authenticate(self):
        auth_data = {
            "auth": {
                "identity": {
                    "methods": ["application_credential"],
                    "application_credential": {
                        "id": self.id,
                        "secret": self.secret
                    }
                }
            }
        }

        headers = {
            "Content-Type": "application/json"
        }

        response = requests.post(self.auth_url, verify=False, headers=headers, data=json.dumps(auth_data))

        if response.status_code == 201:
            self.token = response.headers['X-Subject-Token']
            self._set_service_urls(response.json())
        else:
            raise Exception("Autenticación fallida")

    def _set_service_urls(self, response_json):
        for service in response_json['token']['catalog']:
            for endpoint in service['endpoints']:
                if endpoint['interface'] == 'public':
                    if service['name'] == 'nova':
                        self.nova_url = endpoint['url']
                    elif service['name'] == 'neutron':
                        self.neutron_url = endpoint['url']
                    elif service['name'] == 'glance':
                        self.glance_url = endpoint['url']

    def get_projects(self):
        if not self.token:
            raise Exception("No autenticado. Llama al método 'authenticate' primero.")

        url = f"{self.auth_url.rsplit('/', 2)[0]}/projects?domain_id=default"
        headers = {
            "X-Auth-Token": self.token,
            "Content-Type": "application/json"
        }

        response = requests.get(url, verify=False, headers=headers)

        if response.status_code == 200:
            return response.json()['projects']
        else:
            raise Exception("Error al obtener proyectos")

    def get_hypervisors(self):
        if not self.token:
            raise Exception("No autenticado. Llama al método 'authenticate' primero.")

        url = f"{self.nova_url}/os-hypervisors"
        headers = {
            "X-Auth-Token": self.token
        }

        response = requests.get(url, verify=False, headers=headers)

        if response.status_code == 200:
            return response.json()['hypervisors']
        else:
            raise Exception("Error al obtener hipervisores")

    def get_servers(self):
        if not self.token:
            raise Exception("No autenticado. Llama al método 'authenticate' primero.")

        url = f"{self.nova_url}/servers/detail?all_tenants=1"
        headers = {
            "X-Auth-Token": self.token
        }

        response = requests.get(url, verify=False, headers=headers)

        if response.status_code == 200:
            return response.json()['servers']
        else:
            raise Exception("Error al obtener servidores")

def get_client(sitio):
    try:
        # Dividir el string 'sitio' en partes
        parts = sitio.split('-')
        
        # Verificar que el sitio tiene el formato correcto
        if len(parts) != 2 or parts[1] not in ['tc', 'tt']:
            raise ValueError("Formato de 'sitio' inválido. Debe ser 'sitio-tc' o 'sitio-tt'")
        
        # Asignar valores de prefijo y sufijo
        site_prefix = parts[0].upper()  # SITIO
        env_suffix = parts[1].upper()   # TC o TT
        
        # Construir las claves dinámicamente
        auth_url_key = f"OPENSTACK_{site_prefix}_{env_suffix}_URL"
        id_key = f"OPENSTACK_{site_prefix}_{env_suffix}_ID"
        secret_key = f"OPENSTACK_{site_prefix}_{env_suffix}_SECRET"

        # Obtener las variables de entorno
        auth_url = config(auth_url_key)
        id = config(id_key)
        secret = config(secret_key)

        if not auth_url or not id or not secret:
            raise Exception(f"Falta la configuración para {sitio}")

        client = OpenStackClient(auth_url, id, secret)
        client.authenticate()
        return client

    except ValueError as e:
        print(e)
        raise

    except Exception as e:
        print(e)
        raise

@app.route('/openstack/<sitio>', methods=['GET'])
def get_servers(sitio):
    try:
        client = get_client(sitio)
    
        # Obtener proyectos y crear un diccionario de proyectos
        projects = client.get_projects()
        project_dict = {project['id']: project['name'] for project in projects}
    
        # Obtener servidores
        servers = client.get_servers()
    
        # Filtrar servidores con sus proyectos
        filtered_servers = []
        for server in servers:
            project_id = server['tenant_id']
            if project_id in project_dict:
                project_name = project_dict[project_id]
                server['project_name'] = project_name
                filtered_servers.append(server)
    
        # Aplicar filtros
        project_name_filter = request.args.get('project_name')
        hypervisor_filter = request.args.get('hypervisor')
    
        if project_name_filter:
            filtered_servers = [server for server in filtered_servers if server['project_name'] == project_name_filter]
        
        if hypervisor_filter:
            filtered_servers = [server for server in filtered_servers if server['OS-EXT-SRV-ATTR:host'] == hypervisor_filter]
    
        # Crear resultado final
        result = []
        for server in filtered_servers:
            result.append({
                "Host": server['OS-EXT-SRV-ATTR:host'],
                "Nombre": server['name'],
                "Estado": server['status'],
                "Project": server['project_name']
            })
    
        return jsonify(result)
    
    except ValueError as e:
        response = {
            "error": str(e)
        }
        return jsonify(response), 400
    
    except Exception as e:
        response = {
            "error": str(e)
        }
        return jsonify(response), 500

@app.route('/openstack/<sitio>/hypervisors', methods=['GET'])
def get_hypervisors(sitio):
    client = get_client(sitio)

    # Obtener hipervisores
    hypervisors = client.get_hypervisors()

    # Aplicar filtro de hipervisor si está presente
    hypervisor_filter = request.args.get('hypervisor_name')
    if hypervisor_filter:
        hypervisors = [hypervisor for hypervisor in hypervisors if hypervisor['hypervisor_hostname'] == hypervisor_filter]

    # Crear resultado final
    result = []
    for hypervisor in hypervisors:
        result.append({
            "Hypervisor": hypervisor['hypervisor_hostname'],
            "Estado": hypervisor['state'],
            "Estatus": hypervisor['status']
        })

    return jsonify(result)

@app.route('/openstack/<sitio>/project', methods=['GET'])
def get_projects(sitio):
    client = get_client(sitio)

    # Obtener proyectos
    projects = client.get_projects()

    # Aplicar filtro de proyecto si está presente
    project_filter = request.args.get('project_name')
    if project_filter:
        projects = [project for project in projects if project['name'] == project_filter]

    # Crear resultado final
    result = []
    for project in projects:
        result.append({
            "Project": project['name'],
            "Description": project['description'],
            "ID": project['id']
        })

    return jsonify(result)

@app.route('/config/openstack', methods=['GET'])
def get_config():
    try:
        # Crear un diccionario para almacenar la estructura anidada
        config_data = {}
        
        # Recorrer las variables de entorno que empiezan con 'OPENSTACK'
        for key in os.environ:
            if key.startswith('OPENSTACK'):
                # Eliminar el prefijo 'OPENSTACK'
                clean_key = key.replace('OPENSTACK_', '')

                # Dividir la clave en partes (ej. CUYO_TC_URL -> ['CUYO', 'TC', 'URL'])
                parts = clean_key.split('_')

                if len(parts) == 3:
                    region, service, field = parts
                    
                    # Crear la estructura anidada para cada región y servicio si no existe
                    if region not in config_data:
                        config_data[region] = {}
                    if service not in config_data[region]:
                        config_data[region][service] = {}
                    


        # Retornar la estructura como JSON
        return jsonify(config_data)
    
    except Exception as e:
        response = {
            "error": str(e)
        }
        return jsonify(response), 500
    
    except Exception as e:
        response = {
            "error": str(e)
        }
        return jsonify(response), 500

@app.route('/config/openstack/all', methods=['GET'])
def get_config_all():
    try:
        # Crear un diccionario para almacenar la estructura anidada
        config_data = {}
        
        # Recorrer las variables de entorno que empiezan con 'OPENSTACK'
        for key in os.environ:
            if key.startswith('OPENSTACK'):
                # Eliminar el prefijo 'OPENSTACK'
                clean_key = key.replace('OPENSTACK_', '')

                # Dividir la clave en partes (ej. CUYO_TC_URL -> ['CUYO', 'TC', 'URL'])
                parts = clean_key.split('_')

                if len(parts) == 3:
                    region, service, field = parts
                    
                    # Crear la estructura anidada para cada región y servicio si no existe
                    if region not in config_data:
                        config_data[region] = {}
                    if service not in config_data[region]:
                        config_data[region][service] = {}
                    
                    
                    ############## Añadir servers por DC ###################
                        if region == 'RPB':
                            sitio = f"{service.lower()}"
                        else:
                            sitio = f"{region.lower()}-{service.lower()}"

                        print(f"DEBUG: Formato de sitio generado: {sitio}")
                        
                        # Obtener el cliente OpenStack
                        client = get_client(sitio)
                        
                        # Obtener servidores y agregar al diccionario
                        servers = client.get_servers()

                        # Obtener proyectos y crear un diccionario de proyectos
                        projects = client.get_projects()
                        project_dict = {project['id']: project['name'] for project in projects}
                        
                        # Filtrar servidores con sus proyectos
                        filtered_servers = []
                        for server in servers:
                            project_id = server['tenant_id']
                            if project_id in project_dict:
                                project_name = project_dict[project_id]
                                server['project_name'] = project_name
                                filtered_servers.append(server)
                        
                        # Aplicar filtros
                        project_name_filter = request.args.get('project_name')
                        hypervisor_filter = request.args.get('hypervisor')
                        
                        if project_name_filter:
                            filtered_servers = [server for server in filtered_servers if server['project_name'] == project_name_filter]
                        
                        if hypervisor_filter:
                            filtered_servers = [server for server in filtered_servers if server['OS-EXT-SRV-ATTR:host'] == hypervisor_filter]
                        
                        # Crear resultado final
                        result = []
                        for server in filtered_servers:
                            result.append({
                                "Host": server['OS-EXT-SRV-ATTR:host'],
                                "Nombre": server['name'],
                                "Estado": server['status'],
                                "Project": server['project_name']
                            })
                        
                        # Agregar el resultado filtrado al diccionario de configuración
                        config_data[region][service] = result


        # Retornar la estructura como JSON
        return jsonify(config_data)
    
    except Exception as e:
        response = {
            "error": str(e)
        }
        return jsonify(response), 500
    
    except Exception as e:
        response = {
            "error": str(e)
        }
        return jsonify(response), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
