# Terraform: Generalidad de funcionamiento

![terraform-generic](doc/imgs/terraform-generic.jpg?raw=true "terraform-generic.jpg")


# Terraform: Componentes del proyecto

![Terraform_vdi](doc/imgs/Terraform_vdi.jpg?raw=true "Terraform_vdi.jpg")
