
Set-Location -Path "C:\Program Files\Cloudbase Solutions\Cloudbase-Init\conf"
pwd
cmd /c "C:\Windows\System32\Sysprep\sysprep.exe  /generalize /oobe /shutdown /unattend:Unattend.xml"
