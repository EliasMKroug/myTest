# - Ocultar shutdown:
$regPath = "HKLM:\SOFTWARE\Microsoft\PolicyManager\default\Start\HideShutDown"
$value = 1
Set-ItemProperty -Path $regPath -Name "value" -Value $value -Force

#- Ocultar sleep:
$regPath = "HKLM:\SOFTWARE\Microsoft\PolicyManager\default\Start\HideSleep"
$value = 1
Set-ItemProperty -Path $regPath -Name "value" -Value $value -Force

#- Desactivar hibernacion:
$regPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Power"
$value = 0
$name= "HibernateEnabledDefault"
Set-ItemProperty -Path $regPath -Name $name -Value $value -Force
