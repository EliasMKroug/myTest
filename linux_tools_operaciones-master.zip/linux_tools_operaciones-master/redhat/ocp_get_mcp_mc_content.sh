#!/bin/bash
################################################################################
# Retorna detalles de un machineConfigPool
# Nos ha resultado util para obtener el orden de los machineConfig que se aplican
#  y conocer el detalle de como quedara finalmente la config. a desplegar
# Util cuando mas de un machineConfig, o kubeletConfig es aplicado, y no se sabe
#  cual finalmente compondra el machineConfig rendered final
################################################################################

error(){ echo "$(date '+%H:%M:%S'): $@"; exit 1 ;}
morir(){ error "$@"; exit 1 ;}
help(){
  cat<<-EOF
  -Lista los machine config. que componen un mcp
  $mi --mcp mcp 

  -Lista el contenido de un machine config espec. de un mcp
  $mi --mcp mcp --mc mc 

  -Lista los mc que modifiquen el archivo /etc/kubernetes/kubelet.conf mostrando 
   las lineas en el que coincidan con un patron 
  $mi --mcp mcp --kubelet_conf patron 

  -Lista los mc que modifiquen el archivo file_path, mostrando 
   las lineas en el que coincidan con un patron 
  $mi --mcp mcp --file file_path --cont patron

  Donde:
    --mcp          mcp      : Busca detalles sobre el mcp "mcp"

    --mc           mc       : Examina solamente el machine config "mc"

    --file file_path_patron : Cuando lista machineConfigs, busca que se configure un
                              archivo cuyo path haga match con el patron file_path_patron
                              muestra su contenido
                              Ej: --file chrony.conf 
    --cont patron           : Cuando lista machineConfigs, busca en cada archivo que se 
                               despliega , las lineas que coincidan con el patron "patron"
                              Ej: --cont server

    --kubelet_conf patron   : Es un sinonimo de usar :
                              --file /etc/kubernetes/kubelet.conf --cont patron
                              Ej: --kubelet_conf maxPods
	EOF
}
OK_COLOR="\e[32m"
ERROR_COLOR="\e[31m"
NO_COLOR="\e[0m"

################################################################################
mi="$0"

while [ -n "$1" ];do
  case "$1" in
    --mcp) 
      [ -n "$2" ] || morir "$1 requiere un argumento"
      MCP="$2"
      shift 2;;
    --mc) 
      [ -n "$2" ] || morir "$1 requiere un argumento"
      MC="$2"
      shift 2;;
    --kubelet_conf) 
      [ -n "$2" ] || morir "$1 requiere un argumento"
      FILE_PATTERN="/etc/kubernetes/kubelet.conf"
      CONT_PATTERN="$2"
      shift 2;;
    --file) 
      [ -n "$2" ] || morir "$1 requiere un argumento"
      FILE_PATTERN="$2"
      shift 2;;
    --cont) 
      [ -n "$2" ] || morir "$1 requiere un argumento"
      CONT_PATTERN="$2"
      shift 2;;

    --help) 
      help ; exit 0 ;;

    *) error "Parametro \"$1\" no soportado"; help ; shift 1 ;;
  esac
done

#Parametros obligatorios
[ -n "$MCP" ] || morir "Se requiere especificar un machineConfigPool usando --mcp"

echo -e "MCP: ${ERROR_COLOR}${MCP}${NO_COLOR}"
echo "Detalle de machineConfigs que lo componen:"

machineConfigs=$( oc get mcp $MCP -o json | jq -r '.spec.configuration.source[].name' )
for mc in $machineConfigs;do

  #Solo opera sobre el mc solicitado
  if [ -n "$MC" -a "$MC" != "$mc" ];then continue; fi

  echo -e "  ${OK_COLOR}${mc}${NO_COLOR}"

  #Se solicita buscar mc referidos a arch. $FILE_PATTERN
  if [ -n "$FILE_PATTERN" -o -n "$MC" ] ;then
    file_content=$( oc get mc $mc -o json | \
        jq '.spec.config.storage.files[] ' 2>/dev/null | \
	jq -r "select( .path | contains(\"$FILE_PATTERN\")) | .contents.source" 2>/dev/null)
  fi

  if echo "$file_content" |egrep -q '^data:text/plain;charset=utf-8;base64,' ;then
    file_content=$(echo "$file_content" |sed -e 's|^data:text/plain;charset=utf-8;base64,||' | base64 -d )
  elif echo "$file_content" |egrep -q '^data:,kind%3A%20KubeletConfiguration%0A' ;then
    file_content=$(echo "$file_content" |sed -e 's|^data:,kind%3A%20KubeletConfiguration%0A||' | \
      sed -e 's/%0A/\n/g' | \
      sed -e 's/%3A/:/g'  | \
      sed -e 's/%2F/\//g'  | \
      sed -e 's/%20/ /g' 
      )
  fi

  if [ -n "$file_content" -a -z "$CONT_PATTERN"  ];then
    echo "$file_content" | sed -e 's/^/    /g'
  elif [ -n "$file_content" -a -n "$CONT_PATTERN"  ];then
    echo "$file_content" | egrep -i "$CONT_PATTERN" | sed -e 's/^/    /g'
  fi

done
