#!/bin/bash

# Obtén la lista de proyectos en el dominio 'default'
projects=$(openstack project list --domain default | awk 'NR>3 {print $4}' | sed '/^$/d')

# Itera sobre cada proyecto y ejecuta el comando para listar instancias
for PROJECT in $projects; do
     # Ejecuta el comando para obtener la lista de instancias del proyecto
    instances=$(openstack server list --project $PROJECT -f value -c ID)

    # Comprueba si la variable instances está vacía
    if [ -n "$instances" ]; then
        echo "Instancias en project $PROJECT"
        echo ""
	openstack server list --project $PROJECT --long -c Name -c Status -c "Power State" -c "Host"
	echo ""
    else
	echo ""
        echo "No hay instancias en project $PROJECT"
	echo ""
    fi
done
