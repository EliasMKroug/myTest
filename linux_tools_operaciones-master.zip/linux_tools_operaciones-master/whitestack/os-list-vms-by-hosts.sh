#!/bin/bash

# Obtén la lista de servidores
hosts=$(openstack hypervisor list | awk 'NR>3 {print $4}' | sed '/^$/d')

# Itera sobre cada proyecto y ejecuta el comando para listar instancias
for HOSTS in $hosts; do
    echo "Instancias en host $HOSTS"
    echo ""
    openstack server list --all --host $HOSTS --long -c Name -c Status -c "Power State" -c "Host"
    echo ""
done

