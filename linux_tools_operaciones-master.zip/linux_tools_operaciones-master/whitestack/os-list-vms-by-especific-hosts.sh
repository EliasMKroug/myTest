#!/bin/bash
set -e

# Función para mostrar ayuda
mostrar_ayuda() {
    echo ""
    echo "Uso: $0 [--hosts-file FILE] [--hosts host1,host2,...] [--help]"
    echo "    --hosts-file FILE        Archivo que contiene una lista de hosts (uno por línea)"
    echo "    --hosts host1,host2,...  Lista de hosts separados por comas"
    echo "    --help                   Muestra esta ayuda"
    echo ""
}

# Función para listar instancias en un host
listar_instancias() {
    local HOST="$1"
    echo "Instancias en host $HOST"
    echo ""
    OUTPUT=$(openstack server list --all --host $HOST --long -c Name -c Status -c "Power State" -c "Host")

    if [ -z "$OUTPUT" ]; then
	    echo "##### --- No hay instancias en el host $HOST --- #####"
    else
	    echo "$OUTPUT"
    fi
    echo ""
}

# Comprueba si se han pasado argumentos
if [ "$#" -eq 0 ]; then
    mostrar_ayuda
    exit 1
fi

# Comprueba si el primer argumento es --help
if [[ "$1" == "--help" ]]; then
    mostrar_ayuda
    exit 0
fi

# Procesa los argumentos
while [[ $# -gt 0 ]]; do
    case "$1" in
        --hosts-file)
            if [ ! -f "$2" ]; then
                echo "El archivo $2 no existe."
                exit 1
            fi
            while IFS= read -r HOST || [[ -n "$HOST" ]]; do
                listar_instancias "$HOST"
            done < "$2"
            shift 2
            ;;
        --hosts)
            IFS=',' read -ra HOSTS <<< "$2"
            for HOST in "${HOSTS[@]}"; do
                listar_instancias "$HOST"
            done
            shift 2
            ;;
        *)
            listar_instancias "$1"
            shift
            ;;
    esac
done

