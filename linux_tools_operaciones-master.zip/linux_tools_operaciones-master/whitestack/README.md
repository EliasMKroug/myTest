# Whitestack

Este repositorio cuenta con herramientas en script Bash para realizar operaciones sobre los Openstack que estemos logueados desde nuestra WSL/CLI.

## os-list-vms-by-hosts.sh

El script "os-list-vms-by-hosts.sh", al estar logueado a Openstack y ejecutarlo, muestra todas las VMs/Instancias que estan sobre cada uno de los Hypervisores.

## os-list-vms-by-projects.sh

El script "os-list-vms-by-projects.sh", te muestra todas las VMs/Instancias que estan por cada Project.

## automated-instances.sh

Permite apagar o encender VMs/Instancias de openstack, se puede ejecutar ./automated-instances.sh --help para verificar su funcionamiento:

Uso: ./automated-instances.sh [--action ACTION] [--tenant HYPERVISOR] [--tenant-file FILE] [--exclude-vms INSTANCES] [--preview] [--help]
    --action ACTION       Acción a realizar: 'start' o 'stop'
    --tenant HYPERVISOR   Nombre del hypervisor o lista de hypervisores separados por coma
    --tenant-file FILE    Archivo que contiene una lista de hypervisores (uno por línea)
    --exclude-vms INSTANCES  Instancias a excluir separadas por coma
    --preview             Previsualizar las instancias sin ejecutar la acción
    --help                Mostrar esta ayuda

## os-list-vms-by-especific-hosts.sh

Permite listar las VMs/Instancias por host especifico, se le puede enviar los hosts via argumento con --hosts o un archivo, donde se encuentren los hosts uno por linea, se puede ejecutar ./os-list-vms-by-especific-hosts.sh --help para verificar su funcionamiento:

Uso: ./os-list-vms-by-especific-hosts.sh [--hosts-file FILE] [--hosts host1,host2,...] [--help]
    --hosts-file FILE        Archivo que contiene una lista de hosts (uno por línea)
    --hosts host1,host2,...  Lista de hosts separados por comas
    --help                   Muestra esta ayuda