#!/bin/bash
#set -e

# Función para mostrar ayuda
mostrar_ayuda() {
    echo ""
    echo "Uso: $0 [--action ACTION] [--tenant HYPERVISOR] [--tenant-file FILE] [--exclude-vms INSTANCES] [--preview] [--help]"
    echo "    --action ACTION       Acción a realizar: 'start' o 'stop'"
    echo "    --tenant HYPERVISOR   Nombre del hypervisor o lista de hypervisores separados por coma"
    echo "    --tenant-file FILE    Archivo que contiene una lista de hypervisores (uno por línea)"
    echo "    --exclude-vms INSTANCES  Instancias a excluir separadas por coma"
    echo "    --preview             Previsualizar las instancias sin ejecutar la acción"
    echo "    --help                Mostrar esta ayuda"
    echo ""
}

openstack_server_action() {
    local action="$1"
    local inst_id="$2"
    local inst_name="$3"

    if [[ $action == "start" ]]; then
           echo "###################################################################"
           echo "Encendiendo instancia $inst_name (ID: $inst_id)"
           if [[ $PREVIEW == "true" ]]; then
                   echo "  openstack server start $inst_id | MODO PREVIEW"
           else
                   openstack server start $inst_id
           fi
    elif [[ $action == "stop" ]]; then
           echo "###################################################################"
           echo "Apagando instancia $inst_name (ID: $inst_id)"
           if [[ $PREVIEW == "true" ]]; then
                   echo "openstack server stop $inst_id | MODO PREVIEW"
           else
                   openstack server stop $inst_id
           fi
    fi
}

# Función principal
main() {
    # Variables iniciales
    ACTION=""
    HYPERVISORS=""
    EXCLUDE_VMS=""
    PREVIEW=false

    # Verificar si se proporcionaron argumentos
    if [[ $# -eq 0 ]]; then
        mostrar_ayuda
        return
    fi

    # Parsear los argumentos
    while [[ $# -gt 0 ]]; do
        case $1 in
            --action)
                ACTION="$2"
                shift 2
                ;;
            --tenant)
                HYPERVISORS="$2"
                shift 2
                ;;
            --tenant-file)
                while IFS= read -r line; do
                    HYPERVISORS+="$line,"
                done < "$2"
                shift 2
                ;;
            --exclude-vms)
                EXCLUDE_VMS="$2"
                shift 2
                ;;
            --preview)
                PREVIEW=true
                shift
                ;;
            --help)
                mostrar_ayuda
                return
                ;;
            *)
                echo "Opción no habilitada: $1"
                mostrar_ayuda
                return
                ;;
        esac
    done

    # Verificar que se proporcionó una acción
    if [[ -z $ACTION ]]; then
        echo "Se debe especificar una acción (--action)."
        mostrar_ayuda
        return
    fi

    # Verificar que la acción sea válida
    if [[ $ACTION != "start" && $ACTION != "stop" ]]; then
        echo "Acción inválida: $ACTION"
        mostrar_ayuda
        return
    fi

    # Verificar que se proporcionó al menos un hypervisor
    if [[ -z $HYPERVISORS ]]; then
        echo "Se debe especificar al menos un hypervisor (--tenant o --tenant-file)."
        mostrar_ayuda
        return
    fi

    # Obtener la lista de hypervisores
    IFS=',' read -ra HYPERVISOR_LIST <<< "$HYPERVISORS"

    # Realizar la acción solicitada en los hypervisores
    for HYPERVISOR in "${HYPERVISOR_LIST[@]}"; do
        echo ""
        echo "Realizando la acción '$ACTION' en las instancias del hypervisor $HYPERVISOR..."
        echo ""
        INSTANCIAS=$(openstack server list --all-projects --host $HYPERVISOR -f value -c ID -c Name)
        if [[ -n $INSTANCIAS ]]; then
            # Filtrar instancias excluidas
            if [[ -n $EXCLUDE_VMS ]]; then
                for INSTANCE_ID in $(echo "$EXCLUDE_VMS" | tr "," "\n"); do
                    INSTANCIAS=$(echo "$INSTANCIAS" | grep -v "$INSTANCE_ID")
                done
            fi
            if [[ -n $INSTANCIAS ]]; then
                while IFS= read -r instancia; do
                    INST_ID=$(echo $instancia | awk '{print $1}')
                    INST_NAME=$(echo $instancia | awk '{print $2}')
                    openstack_server_action $ACTION $INST_ID $INST_NAME
                done <<< "$INSTANCIAS"
                echo "Acción '$ACTION' completada en las instancias del hypervisor $HYPERVISOR."
            else
                echo "No se encontraron instancias en el hypervisor $HYPERVISOR después de excluir las especificadas."
            fi
        else
            echo "No se encontraron instancias en el hypervisor $HYPERVISOR."
        fi
    done
}

# Llamar a la función principal
main "$@"
